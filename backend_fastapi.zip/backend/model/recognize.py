import easyocr

reader = easyocr.Reader(['en'])

def detect_plate(image):
    results = reader.readtext(image)
    best = max(results, key=lambda r: r[2]) if results else None
    return best[1] if best else "Không phát hiện"
